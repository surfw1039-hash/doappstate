# Motion Muse — мультимодальный API (Lovable AI)

Проект на TanStack Start. Один универсальный роутер для текста, изображений,
аудио, видео и документов + отдельный эндпоинт генерации видео.

| Эндпоинт | Назначение |
| --- | --- |
| `POST /api/text_model` (и `/api/public/text_model`) | Единый мультимодальный роутер: текст, картинки, речь, видео, файлы, tool calling |
| `POST /api/video_gen` (и `/api/public/video_gen`) | Прямая генерация / редактирование / продолжение видео |

Версии под `/api/public/*` доступны без авторизации сайта. Ключ
`LOVABLE_API_KEY` подставляется на сервере автоматически.

Развёртывание:

```sh
npm i
npm run dev
```

---

## 1. Единый мультимодальный роутер

`POST /api/text_model`

### Тело запроса

```jsonc
{
  "prompt": "Что на фото и нарисуй похожий постер",
  "system": "Ты — краткий ассистент.",          // системный промпт (сервер)
  "messages": [                                  // история диалога
    { "role": "user", "content": "привет" },
    { "role": "assistant", "content": "Здравствуйте!" }
  ],

  "output": ["text", "image", "file", "audio"],  // массив модальностей ответа
  "tools": true,                                  // false — отключить function calling

  "model": "openai/gpt-6-astra",                 // необязательно
  "reasoning": "none" | "low" | "medium" | "high",
  "stream": true,                                 // false → обычный JSON
  "format": "sse" | "ndjson" | "text",

  // вложения — любой из форматов, см. раздел 2
  "attachments": [ { "name": "doc.pdf", "type": "application/pdf", "data": "<base64>" } ],

  // опции медиа-выходов
  "image_prompt": "…", "image_model": "…",
  "voice": "alloy", "audio_model": "…",
  "video": { "resolution": "720p", "duration": 8, "aspect_ratio": "16:9" },
  "file_name": "answer.md", "file_mime": "text/markdown"
}
```

### Модальности `output`

- `text` — обычный текстовый ответ (по умолчанию);
- `image` — к ответу прикладывается сгенерированная картинка;
- `audio` — озвучка ответа (mp3);
- `video` — сгенерированное видео (mp4, 1–3 минуты ожидания);
- `file` — текстовый файл с ответом (`file_name` / `file_mime`).

Можно комбинировать: `"output": ["text", "image", "audio"]`.

**Автопереключение.** Если поле `output` не передано, роутер сам определяет
задачу по формулировке запроса: «нарисуй», «сгенерируй логотип», «draw…» →
включается генерация графики; «озвучь», «прочитай вслух» → озвучка;
«сгенерируй видео», «анимируй» → видео. Явно переданный `output` всегда
имеет приоритет над автоопределением.

**Выбор модели.** По умолчанию `openai/gpt-6-astra` (Responses API, с
рассуждениями). При вложенных видео или аудио запрос автоматически уходит на
мультимодальную `google/gemini-3.8-flash`.

---

## 2. Унифицированный парсер входящих файлов

Файлы принимаются в любом из форматов — разбирает их общий парсер
(`src/lib/attachments.server.ts`):

1. **Объект `file`** — File-подобный:
   `{ "file": { "name": "a.png", "type": "image/png", "data": "<base64 | data:URL>" } }`
2. **Массив `attachments`** (а также `files`, `images`, `image`, `video`,
   `audio`, `documents`, `media`, `experimental_attachments`) — элементы:
   объект как выше, либо `{ "url": "https://…" }`, либо просто строка
   (`"https://…"` или `"data:image/png;base64,…"`).
3. **Вложения внутри `messages[].content[]`** в формате AI SDK / OpenAI:
   `image_url`, `video_url`, `file`, `image`, `audio`.
4. **`multipart/form-data`** — любые файловые поля формы становятся
   вложениями; текстовые поля (`prompt`, `system`, `output`, `messages`, …)
   парсятся как обычные параметры, JSON-строки разбираются автоматически.

Лимиты: до 10 вложений, суммарно ~45 МБ. Ссылки скачиваются на сервере и
передаются модели инлайн.

## 3. Серверная распаковка и конвертация документов

`src/lib/documents.server.ts` приводит вложение к тому, что модель умеет
читать:

| Формат | Что делает сервер |
| --- | --- |
| `txt`, `md`, `csv`, `json`, `xml`, код | декодирование в текст |
| `docx`, `xlsx`, `pptx` | распаковка zip (`fflate`) → текст из OOXML |
| `odt`, `ods`, `odp` | распаковка → текст из `content.xml` |
| `pdf` | нативная передача во Vision-модель **плюс** извлечение текста (FlateDecode + операторы Tj/TJ) |
| изображения | base64 / data URL в блок `image_url` (`input_image`) |
| видео | base64 в блок `video_url` |
| аудио | base64 в блок `input_audio` с определением контейнера |
| прочие бинарные | метаданные + доступ через инструмент `analyze_file` |

Предел извлекаемого текста — 200 000 символов на документ (дальше обрезается,
о чём модели сообщается).

## 4. Строгая спецификация SSE

`Content-Type: text/event-stream`. Каждое событие — именованное:

| Событие | Данные | Когда |
| --- | --- | --- |
| `status` | `{ stage, message }` | этапы: `start`, `attachments`, `model`, `thinking`, `reasoning`, `answering`, `analyze`, `image`, `audio`, `video`, `file`, `done` |
| `reasoning` | `{ delta }` | ход рассуждений модели |
| `text` | `{ delta }` | куски текста ответа |
| `image` | `{ kind, mime, filename, size, base64, data_url }` | готовое изображение |
| `audio` | то же | готовая озвучка |
| `video` | то же | готовое видео |
| `file` | то же | любой файл (для `image`/`audio`/`video` дублирует типизированное событие) |
| `tool` | `{ name, arguments }` | модель вызвала серверный инструмент |
| `error` | `{ error, status }` | ошибка (поток продолжается, если она частичная) |
| `done` | `{ model, text, files? }` | финал |

Легаси-алиас: вместе с `text` дублируется событие `delta` с тем же телом —
старые клиенты продолжают работать.

Другие форматы потока: `"format": "ndjson"` (по строке JSON с полем `event`)
и `"format": "text"` (только чистый текст и статусы).

Пример:

```sh
curl -N -X POST http://localhost:8080/api/public/text_model \
  -H 'Content-Type: application/json' \
  -d '{"prompt":"Нарисуй красную звезду","output":["text","image"]}'
```

## 5. История диалога и системный промпт

- `system` — системный промпт, применяется на сервере, к нему добавляются
  служебные инструкции про инструменты и медиа.
- `messages` — история: `[{ "role": "user" | "assistant" | "system",
  "content": "…" }]`. Поддерживается и массив частей (`content: [{type:"text",
  text:"…"}]`) — текст извлекается автоматически. История передаётся модели
  перед текущим `prompt`, поэтому контекст сохраняется между запросами.
- Вложения из истории тоже собираются парсером и уходят модели.

## 6. Tool / Function Calling

Модель сама решает, какой серверный инструмент вызвать (можно отключить
`"tools": false`):

| Инструмент | Аргументы | Действие |
| --- | --- | --- |
| `generate_image` | `prompt`, `reference_index` | генерация/редактирование картинки, файл уходит событием `image` |
| `generate_speech` | `text`, `voice` | озвучка, событие `audio` |
| `generate_video` | `prompt`, `duration` | видео (доступен, когда в `output` есть `video`) |
| `create_file` | `filename`, `mime`, `content` | текстовый файл с результатом, событие `file` |
| `analyze_file` | `index`, `max_chars` | содержимое вложения #N (распакованный документ или метаданные) |

Цикл вызовов — до 4 раундов; результаты возвращаются модели, после чего она
дописывает финальный текст. Инструментам явно запрещено подменять картинку
SVG, ASCII-артом или ссылкой. Работает на обеих ветках: `/v1/responses`
(OpenAI, с round-trip рассуждений) и `/v1/chat/completions` (остальные
вендоры).

---

## Не-стриминговый ответ

`"stream": false` → обычный JSON:

```json
{
  "model": "openai/gpt-6-astra",
  "text": "…",
  "reasoning": "…",
  "tool_calls": [{ "name": "generate_image", "arguments": { } }],
  "files": [{ "kind": "image", "mime": "image/png", "filename": "image.png", "size": 1234, "base64": "…", "data_url": "data:…" }]
}
```

## Ошибки

JSON `{ "error": "…" }` со статусом: `400` — некорректный запрос, `401` — нет
ключа, `402` — кончились кредиты Lovable AI, `403` — лимит/политика
воркспейса, `429` — слишком много запросов, `5xx` — временный сбой. В потоке
те же ошибки приходят событием `error`.

## `POST /api/video_gen`

Прямая генерация видео. Тело: `prompt`, вложения (стартовый кадр или видео для
продолжения), `resolution`, `duration`, `aspect_ratio`, `async`. При
`"async": true` возвращается `{ id }`, статус — `GET /api/video_gen?id=…`.

## Структура

```
src/lib/attachments.server.ts  — единый парсер входящих файлов и тела запроса
src/lib/documents.server.ts    — распаковка и конвертация документов
src/lib/text-model.server.ts   — мультимодальный роутер, SSE, tool calling
src/lib/media-out.server.ts    — генерация картинок, речи, видео, файлов
src/lib/video-gen.server.ts    — эндпоинт /api/video_gen
src/routes/api/**              — HTTP-маршруты (обычные и public)
```
