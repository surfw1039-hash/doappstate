import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/text_model")({
  server: {
    handlers: {
      OPTIONS: async () => {
        const { handleOptions } = await import("@/lib/text-model.server");
        return handleOptions();
      },
      POST: async ({ request }) => {
        const { postTextModel } = await import("@/lib/text-model.server");
        return postTextModel(request);
      },
    },
  },
});
