import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/video_gen")({
  server: {
    handlers: {
      OPTIONS: async () => {
        const { handleOptions } = await import("@/lib/video-gen.server");
        return handleOptions();
      },
      POST: async ({ request }) => {
        const { postVideoGen } = await import("@/lib/video-gen.server");
        return postVideoGen(request);
      },
      GET: async ({ request }) => {
        const { getVideoGen } = await import("@/lib/video-gen.server");
        return getVideoGen(request);
      },
    },
  },
});
