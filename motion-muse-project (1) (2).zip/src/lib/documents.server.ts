/**
 * Серверная распаковка и конвертация документов.
 *
 * Задача модуля — превратить любой присланный файл в то, что модель реально
 * умеет читать:
 *   • текстовые форматы (txt, md, csv, json, xml, код)  → обычный текст;
 *   • DOCX / XLSX / PPTX / ODT (zip-контейнеры)         → распаковка + текст;
 *   • PDF                                                → нативный файл для
 *     Vision-модели + best-effort извлечение текста;
 *   • изображения / видео / аудио                        → бинарный поток в
 *     base64 (уже готов в attachments.server).
 */

import { Buffer } from "node:buffer";
import { unzipSync, inflateSync } from "fflate";
import type { NormalizedAttachment } from "./attachments.server";

/** Максимум символов текста, извлечённого из одного документа. */
export const MAX_DOC_CHARS = 200_000;

export type ExtractedDocument = {
  /** Извлечённый текст (пустая строка — извлечь не удалось). */
  text: string;
  /** Текст был обрезан по лимиту. */
  truncated: boolean;
  /** Как именно получен текст. */
  via: "plain" | "ooxml" | "odf" | "pdf" | "none";
};

const TEXTUAL =
  /^(text\/|application\/(json|xml|xhtml\+xml|x-yaml|yaml|javascript|typescript|sql|x-sh|x-httpd-php|csv))/;

const OOXML = new Set([
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document", // docx
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // xlsx
  "application/vnd.openxmlformats-officedocument.presentationml.presentation", // pptx
]);

const ODF = new Set([
  "application/vnd.oasis.opendocument.text",
  "application/vnd.oasis.opendocument.spreadsheet",
  "application/vnd.oasis.opendocument.presentation",
]);

export function isTextualMime(mime: string) {
  return TEXTUAL.test(mime);
}

/** Можно ли из файла достать текст на сервере. */
export function isDocumentMime(mime: string, filename = "") {
  const ext = filename.split(".").pop()?.toLowerCase() ?? "";
  return (
    TEXTUAL.test(mime) ||
    OOXML.has(mime) ||
    ODF.has(mime) ||
    ["docx", "xlsx", "pptx", "odt", "ods", "odp", "txt", "md", "csv", "json", "xml"].includes(ext)
  );
}

function bytesOf(a: NormalizedAttachment): Uint8Array {
  return new Uint8Array(Buffer.from(a.base64, "base64"));
}

function decode(bytes: Uint8Array) {
  return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
}

/** Убирает XML-теги, оставляя читаемый текст с переносами по абзацам. */
function xmlToText(xml: string) {
  return xml
    .replace(/<(w:p|a:p|text:p|text:h|tr|\/table:table-row)[^>]*>/g, "\n")
    .replace(/<(w:br|w:tab|a:br)[^>]*\/?>/g, " ")
    .replace(/<[^>]+>/g, "")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** DOCX / XLSX / PPTX / ODT: распаковываем zip и собираем текст из XML. */
function unzipToText(bytes: Uint8Array): { text: string; via: "ooxml" | "odf" } | null {
  let files: Record<string, Uint8Array>;
  try {
    files = unzipSync(bytes);
  } catch {
    return null;
  }

  const pick = (re: RegExp) =>
    Object.keys(files)
      .filter((n) => re.test(n))
      .sort();

  // ODF
  const odf = pick(/^content\.xml$/);
  if (odf.length) {
    const parts = odf.map((n) => xmlToText(decode(files[n] as Uint8Array)));
    return { text: parts.join("\n\n").trim(), via: "odf" };
  }

  const names = [
    ...pick(/^word\/document\.xml$/),
    ...pick(/^word\/(header|footer)\d*\.xml$/),
    ...pick(/^ppt\/slides\/slide\d+\.xml$/),
    ...pick(/^ppt\/notesSlides\/notesSlide\d+\.xml$/),
    ...pick(/^xl\/sharedStrings\.xml$/),
    ...pick(/^xl\/worksheets\/sheet\d+\.xml$/),
  ];
  if (!names.length) return null;

  const chunks: string[] = [];
  for (const n of names) {
    const t = xmlToText(decode(files[n] as Uint8Array));
    if (t) chunks.push(t);
  }
  return { text: chunks.join("\n\n").trim(), via: "ooxml" };
}

/**
 * PDF: best-effort извлечение текста без внешних зависимостей.
 * Распаковываются FlateDecode-потоки, из них берётся содержимое операторов
 * Tj / TJ. Работает не для всех PDF (сканы и хитрые кодировки не поддаются),
 * поэтому PDF всегда дополнительно уходит в модель как нативный файл.
 */
function pdfToText(bytes: Uint8Array): string {
  const latin = Buffer.from(bytes).toString("latin1");
  const out: string[] = [];

  const pushOps = (content: string) => {
    const re = /\((?:\\.|[^\\()])*\)\s*Tj|\[(?:[^\]\\]|\\.)*\]\s*TJ/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(content))) {
      const literals = m[0].match(/\((?:\\.|[^\\()])*\)/g) ?? [];
      const line = literals
        .map((l) =>
          l
            .slice(1, -1)
            .replace(/\\([nrt])/g, (_, c: string) => (c === "n" ? "\n" : c === "r" ? "" : "\t"))
            .replace(/\\([()\\])/g, "$1")
            .replace(/\\(\d{1,3})/g, (_, o: string) => String.fromCharCode(parseInt(o, 8))),
        )
        .join("");
      if (line.trim()) out.push(line);
    }
  };

  const streamRe = /stream\r?\n?([\s\S]*?)endstream/g;
  let s: RegExpExecArray | null;
  while ((s = streamRe.exec(latin))) {
    const raw = Buffer.from(s[1] as string, "latin1");
    let content = "";
    try {
      content = Buffer.from(inflateSync(new Uint8Array(raw))).toString("latin1");
    } catch {
      content = raw.toString("latin1");
    }
    if (content.includes("Tj") || content.includes("TJ")) pushOps(content);
  }

  return out.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}

/** Основная точка входа: достаёт текст из документа любого поддержанного типа. */
export function extractDocumentText(a: NormalizedAttachment): ExtractedDocument {
  if (!a.base64) return { text: "", truncated: false, via: "none" };

  const ext = a.filename.split(".").pop()?.toLowerCase() ?? "";
  let text = "";
  let via: ExtractedDocument["via"] = "none";

  try {
    if (TEXTUAL.test(a.mime) || ["txt", "md", "csv", "json", "xml", "log"].includes(ext)) {
      text = decode(bytesOf(a));
      via = "plain";
    } else if (a.mime === "application/pdf" || ext === "pdf") {
      text = pdfToText(bytesOf(a));
      via = text ? "pdf" : "none";
    } else if (
      OOXML.has(a.mime) ||
      ODF.has(a.mime) ||
      a.mime === "application/zip" ||
      ["docx", "xlsx", "pptx", "odt", "ods", "odp"].includes(ext)
    ) {
      const r = unzipToText(bytesOf(a));
      if (r) {
        text = r.text;
        via = r.via;
      }
    }
  } catch {
    return { text: "", truncated: false, via: "none" };
  }

  const truncated = text.length > MAX_DOC_CHARS;
  return { text: truncated ? text.slice(0, MAX_DOC_CHARS) : text, truncated, via };
}
