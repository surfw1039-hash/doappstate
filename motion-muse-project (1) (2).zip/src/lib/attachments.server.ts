/**
 * Нормализация вложений для эндпоинтов /api/text_model и /api/video_gen.
 *
 * Принимаемый формат (любое из полей):
 *   {
 *     "type": "image" | "video" | "audio" | "file",   // необязательно, определяется по mime
 *     "mime_type": "image/png",                        // необязательно, определяется по data-url / url
 *     "data": "<base64>" | "data:image/png;base64,...",// инлайн-данные
 *     "url": "https://...",                            // ссылка (будет скачана при необходимости)
 *     "filename": "report.pdf"
 *   }
 * Также допускается просто строка: "https://..." или "data:image/png;base64,...".
 */

import { Buffer } from "node:buffer";

export type RawAttachment =
  | string
  | {
      type?: string;
      mime_type?: string;
      mimeType?: string;
      data?: string;
      base64?: string;
      url?: string;
      filename?: string;
      name?: string;
    };

export type NormalizedAttachment = {
  kind: "image" | "video" | "audio" | "file";
  mime: string;
  filename: string;
  /** Чистый base64 без префикса data: */
  base64: string;
  /** Исходная ссылка, если вложение пришло ссылкой */
  url?: string;
};

const EXT_MIME: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  webp: "image/webp",
  gif: "image/gif",
  heic: "image/heic",
  mp4: "video/mp4",
  webm: "video/webm",
  mov: "video/quicktime",
  mp3: "audio/mpeg",
  wav: "audio/wav",
  m4a: "audio/mp4",
  ogg: "audio/ogg",
  flac: "audio/flac",
  aac: "audio/aac",
  pdf: "application/pdf",
  txt: "text/plain",
  md: "text/markdown",
  csv: "text/csv",
  json: "application/json",
};

function mimeFromName(name: string): string | undefined {
  const ext = name.split("?")[0]?.split(".").pop()?.toLowerCase();
  return ext ? EXT_MIME[ext] : undefined;
}

function kindOf(mime: string, hint?: string): NormalizedAttachment["kind"] {
  if (hint === "image" || hint === "video" || hint === "audio" || hint === "file") return hint;
  if (mime.startsWith("image/")) return "image";
  if (mime.startsWith("video/")) return "video";
  if (mime.startsWith("audio/")) return "audio";
  return "file";
}

function bytesToBase64(bytes: ArrayBuffer): string {
  return Buffer.from(bytes).toString("base64");
}

export const MAX_ATTACHMENTS = 10;
/** Совокупный лимит инлайн-данных (~45 МБ до base64). */
export const MAX_TOTAL_BYTES = 45 * 1024 * 1024;

export class AttachmentError extends Error {}

export async function normalizeAttachments(
  input: unknown,
  opts: { fetchUrls: boolean },
): Promise<NormalizedAttachment[]> {
  if (input == null) return [];
  const list = Array.isArray(input) ? input : [input];
  if (list.length > MAX_ATTACHMENTS)
    throw new AttachmentError(`Слишком много вложений: максимум ${MAX_ATTACHMENTS}.`);

  const out: NormalizedAttachment[] = [];
  let total = 0;

  for (const raw of list as RawAttachment[]) {
    const item: Exclude<RawAttachment, string> =
      typeof raw === "string"
        ? raw.startsWith("data:")
          ? { data: raw }
          : { url: raw }
        : raw ?? {};

    // Клиенты часто кладут MIME в поле `type` (File-подобный объект).
    const typeField = typeof item.type === "string" ? item.type : "";
    let mime = item.mime_type ?? item.mimeType ?? (typeField.includes("/") ? typeField : "");
    const filename = item.filename ?? item.name ?? "";

    let base64 = "";
    let url: string | undefined;

    const inline = item.data ?? item.base64;
    if (typeof inline === "string" && inline.length > 0) {
      const m = /^data:([^;,]+)(;base64)?,(.*)$/s.exec(inline);
      if (m) {
        mime = mime || (m[1] as string);
        base64 = (m[3] as string).replace(/\s/g, "");
      } else {
        base64 = inline.replace(/\s/g, "");
      }
    } else if (typeof item.url === "string" && item.url.length > 0) {
      url = item.url;
      mime = mime || mimeFromName(url) || "";
      if (opts.fetchUrls) {
        let res: Response;
        try {
          res = await fetch(url);
        } catch {
          throw new AttachmentError(`Не удалось скачать вложение: ${url}`);
        }
        if (!res.ok)
          throw new AttachmentError(`Не удалось скачать вложение (${res.status}): ${url}`);
        mime = mime || res.headers.get("content-type")?.split(";")[0] || "";
        base64 = bytesToBase64(await res.arrayBuffer());
      }
    } else {
      throw new AttachmentError("У вложения должно быть поле 'data' (base64) или 'url'.");
    }

    if (!mime) mime = mimeFromName(filename) || "application/octet-stream";

    if (base64) {
      total += Math.floor((base64.length * 3) / 4);
      if (total > MAX_TOTAL_BYTES)
        throw new AttachmentError("Суммарный размер вложений слишком большой (лимит ~45 МБ).");
    }

    out.push({
      kind: kindOf(mime, item.type),
      mime,
      filename: filename || `attachment.${mime.split("/")[1] ?? "bin"}`,
      base64,
      ...(url ? { url } : {}),
    });
  }

  return out;
}

export function dataUrl(a: NormalizedAttachment): string {
  return a.base64 ? `data:${a.mime};base64,${a.base64}` : (a.url as string);
}

/* ------------------- универсальный разбор тела запроса --------------------- */

/** Все поля, в которых клиент может прислать файл(ы). */
const ATTACHMENT_KEYS = [
  "attachments",
  "attachment",
  "files",
  "file",
  "media",
  "image",
  "images",
  "video",
  "videos",
  "audio",
  "document",
  "documents",
  "experimental_attachments",
];

/** Собирает вложения из любого поля JSON-тела, включая вложения в messages[]. */
export function collectAttachmentInput(payload: Record<string, unknown>): RawAttachment[] {
  const out: RawAttachment[] = [];
  const push = (v: unknown) => {
    if (v == null) return;
    if (Array.isArray(v)) v.forEach(push);
    else if (typeof v === "string" || typeof v === "object") out.push(v as RawAttachment);
  };
  for (const k of ATTACHMENT_KEYS) push(payload[k]);

  const messages = payload["messages"];
  if (Array.isArray(messages)) {
    for (const m of messages as Array<Record<string, unknown>>) {
      if (!m || typeof m !== "object") continue;
      for (const k of ATTACHMENT_KEYS) push(m[k]);
      // Формат AI SDK: content: [{ type: "image", image: "data:..." }, ...]
      const content = m["content"];
      if (Array.isArray(content)) {
        for (const part of content as Array<Record<string, unknown>>) {
          if (!part || typeof part !== "object") continue;
          const t = String(part["type"] ?? "");
          if (t === "image" || t === "video" || t === "audio" || t === "file") {
            push(part[t] ?? part["data"] ?? part["url"] ?? part);
          } else if (t === "image_url") {
            push((part["image_url"] as { url?: string } | undefined)?.url);
          } else if (t === "video_url") {
            push((part["video_url"] as { url?: string } | undefined)?.url);
          }
        }
      }
    }
  }
  return out;
}

/**
 * Читает тело запроса как JSON или как multipart/form-data.
 * Возвращает обычный объект payload; файлы из FormData складываются
 * в payload.attachments уже в нормализованном виде (base64 + mime).
 */
export async function readRequestPayload(
  request: Request,
): Promise<Record<string, unknown> | null> {
  const ctype = request.headers.get("content-type") ?? "";

  if (ctype.includes("multipart/form-data") || ctype.includes("application/x-www-form-urlencoded")) {
    let form: FormData;
    try {
      form = await request.formData();
    } catch {
      return null;
    }
    const payload: Record<string, unknown> = {};
    const files: RawAttachment[] = [];

    for (const [key, value] of form.entries()) {
      if (typeof value !== "string") {
        const blob = value as File;
        const buf = await blob.arrayBuffer();
        files.push({
          mime_type: blob.type || mimeFromName(blob.name ?? "") || "application/octet-stream",
          filename: blob.name || "attachment",
          data: bytesToBase64(buf),
        });
        continue;
      }
      // JSON-строки внутри формы (например, messages или video-настройки)
      const trimmed = value.trim();
      if (
        (trimmed.startsWith("{") || trimmed.startsWith("[")) &&
        (trimmed.endsWith("}") || trimmed.endsWith("]"))
      ) {
        try {
          payload[key] = JSON.parse(trimmed);
          continue;
        } catch {
          /* обычная строка */
        }
      }
      if (key === "duration" && trimmed !== "" && !Number.isNaN(Number(trimmed))) {
        payload[key] = Number(trimmed);
        continue;
      }
      if (key === "stream" || key === "async") {
        payload[key] = trimmed !== "false";
        continue;
      }
      payload[key] = value;
    }

    const fromFields = collectAttachmentInput(payload);
    payload["attachments"] = [...files, ...fromFields];
    return payload;
  }

  try {
    const parsed = (await request.json()) as unknown;
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed))
      return parsed as Record<string, unknown>;
    return null;
  } catch {
    return null;
  }
}

