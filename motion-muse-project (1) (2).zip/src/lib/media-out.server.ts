/**
 * Генерация медиа-ответов (картинки, озвучка, видео) для эндпоинта text_model.
 * Все функции возвращают готовый файл в base64, чтобы его можно было отдать
 * клиенту прямо в потоке событий.
 */

import { Buffer } from "node:buffer";

const BASE = "https://ai.gateway.lovable.dev/v1";

export const IMAGE_MODEL = "google/gemini-3.1-flash-image";
export const AUDIO_MODEL = "openai/gpt-4o-mini-tts";
export const VIDEO_MODEL = "google/gemini-omni-1.1-flash";

export type GeneratedFile = {
  kind: "image" | "audio" | "video" | "file";
  mime: string;
  filename: string;
  size: number;
  base64: string;
};

export class MediaError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

function b64size(b64: string) {
  return Math.floor((b64.length * 3) / 4);
}

async function readError(res: Response) {
  const raw = await res.text().catch(() => "");
  try {
    const j = JSON.parse(raw) as { message?: string; error?: { message?: string } };
    return j.error?.message ?? j.message ?? raw;
  } catch {
    return raw;
  }
}

function bytesToBase64(buf: ArrayBuffer) {
  return Buffer.from(buf).toString("base64");
}

/** Картинка: генерация или редактирование по референсам. */
export async function generateImage(
  apiKey: string,
  prompt: string,
  refs: Array<{ mime: string; base64: string }> = [],
  model = IMAGE_MODEL,
): Promise<GeneratedFile> {
  const content: unknown[] = [{ type: "text", text: prompt }];
  for (const r of refs)
    content.push({ type: "image_url", image_url: { url: `data:${r.mime};base64,${r.base64}` } });

  const res = await fetch(`${BASE}/images/generations`, {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model,
      messages: [{ role: "user", content }],
      modalities: ["image", "text"],
    }),
  });
  if (!res.ok) throw new MediaError(res.status, await readError(res));

  const j = (await res.json()) as { data?: Array<{ b64_json?: string; url?: string }> };
  const item = j.data?.[0];
  if (item?.b64_json)
    return {
      kind: "image",
      mime: "image/png",
      filename: "image.png",
      size: b64size(item.b64_json),
      base64: item.b64_json,
    };
  if (item?.url) {
    const dl = await fetch(item.url);
    const buf = await dl.arrayBuffer();
    const base64 = bytesToBase64(buf);
    return {
      kind: "image",
      mime: dl.headers.get("content-type") ?? "image/png",
      filename: "image.png",
      size: buf.byteLength,
      base64,
    };
  }
  throw new MediaError(502, "Модель не вернула изображение.");
}

/** Озвучка текста. */
export async function generateSpeech(
  apiKey: string,
  text: string,
  voice = "alloy",
  model = AUDIO_MODEL,
): Promise<GeneratedFile> {
  const res = await fetch(`${BASE}/audio/speech`, {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model, input: text.slice(0, 4000), voice, response_format: "mp3" }),
  });
  if (!res.ok) throw new MediaError(res.status, await readError(res));
  const buf = await res.arrayBuffer();
  return {
    kind: "audio",
    mime: res.headers.get("content-type") ?? "audio/mpeg",
    filename: "speech.mp3",
    size: buf.byteLength,
    base64: bytesToBase64(buf),
  };
}

/** Видео: создаёт задачу и дожидается результата. */
export async function generateVideo(
  apiKey: string,
  prompt: string,
  opts: {
    resolution?: string;
    duration?: number;
    aspect_ratio?: string;
    refs?: Array<{ kind: string; mime: string; base64: string }>;
    onProgress?: (message: string) => void;
  } = {},
): Promise<GeneratedFile> {
  const parts: unknown[] = [{ type: "text", text: prompt }];
  let hasVideoRef = false;
  for (const r of opts.refs ?? []) {
    if (r.kind === "image") parts.push({ type: "image", data: r.base64, mime_type: r.mime });
    else if (r.kind === "video") {
      hasVideoRef = true;
      parts.push({ type: "video", data: r.base64, mime_type: r.mime });
    }
  }

  const create = await fetch(`${BASE}/videos`, {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: VIDEO_MODEL,
      input: parts.length > 1 ? parts : prompt,
      response_format: {
        type: "video",
        resolution: opts.resolution ?? "720p",
        duration: `${opts.duration ?? 8}s`,
        ...(opts.aspect_ratio && !hasVideoRef ? { aspect_ratio: opts.aspect_ratio } : {}),
      },
    }),
  });
  if (!create.ok) throw new MediaError(create.status, await readError(create));
  const job = (await create.json()) as { id: string };

  const deadline = Date.now() + 5 * 60 * 1000;
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, 6000));
    const st = await fetch(`${BASE}/videos/${job.id}`, {
      headers: { Authorization: `Bearer ${apiKey}` },
    });
    const j = (await st.json().catch(() => null)) as
      | { status?: string; progress?: number; error?: { message?: string } }
      | null;
    if (!st.ok) throw new MediaError(st.status, await readError(st));
    if (j?.status === "failed")
      throw new MediaError(502, j.error?.message ?? "Генерация видео не удалась.");
    if (j?.status === "completed") {
      const dl = await fetch(`${BASE}/videos/${job.id}/content`, {
        headers: { Authorization: `Bearer ${apiKey}` },
      });
      if (!dl.ok) throw new MediaError(502, "Не удалось скачать готовое видео.");
      const buf = await dl.arrayBuffer();
      return {
        kind: "video",
        mime: "video/mp4",
        filename: `${job.id}.mp4`,
        size: buf.byteLength,
        base64: bytesToBase64(buf),
      };
    }
    opts.onProgress?.(
      `Видео генерируется… ${j?.progress != null ? `${j.progress}%` : (j?.status ?? "в работе")}`,
    );
  }
  throw new MediaError(504, "Генерация видео заняла слишком много времени.");
}

/** Текстовый файл, собранный из ответа модели (md, csv, json, код и т.п.). */
export function textFile(name: string, mime: string, content: string): GeneratedFile {
  const bytes = new TextEncoder().encode(content);
  const base64 = Buffer.from(bytes).toString("base64");
  return { kind: "file", mime, filename: name, size: bytes.length, base64 };
}
