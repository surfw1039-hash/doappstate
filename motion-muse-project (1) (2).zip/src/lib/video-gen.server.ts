import {
  AttachmentError,
  collectAttachmentInput,
  normalizeAttachments,
  readRequestPayload,
  type NormalizedAttachment,
} from "./attachments.server";


const GATEWAY = "https://ai.gateway.lovable.dev/v1/videos";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

type ErrBody = { error: string; code?: string | undefined; details?: unknown };

function jsonError(status: number, body: ErrBody) {
  return new Response(JSON.stringify(body, null, 2), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

function friendly(status: number, message: string) {
  if (status === 402)
    return `Недостаточно кредитов для генерации видео. ${message}`;
  if (status === 403)
    return `Генерация заблокирована настройками воркспейса или лимитом кредитов. ${message}`;
  if (status === 429)
    return `Слишком много запросов или уже идёт другая генерация. ${message}`;
  if (status === 400) return `Некорректный запрос: ${message}`;
  if (status === 401) return `Ключ AI Gateway отсутствует или недействителен.`;
  return message || "Ошибка генерации видео.";
}

const ALLOWED_RES = ["360p", "720p", "1080p", "4k"] as const;
const ALLOWED_AR = ["16:9", "9:16"] as const;

export function handleOptions() {
  return new Response(null, { status: 204, headers: CORS });
}

export async function createJob(payload: Record<string, unknown>) {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) return jsonError(500, { error: "LOVABLE_API_KEY не настроен на сервере." });

  const prompt =
    typeof payload["prompt"] === "string"
      ? payload["prompt"].trim()
      : typeof payload["text"] === "string"
        ? (payload["text"] as string).trim()
        : "";

  // Вложения: картинки (image-to-video, first/last frame, референсы) и видео
  // (редактирование / продолжение клипа). Ссылки скачиваются и передаются inline.
  let attachments: NormalizedAttachment[];
  try {
    attachments = await normalizeAttachments(collectAttachmentInput(payload), { fetchUrls: true });
  } catch (e) {
    if (e instanceof AttachmentError) return jsonError(400, { error: e.message });
    throw e;
  }


  if ((!prompt || prompt.length < 3) && attachments.length === 0)
    return jsonError(400, {
      error: "Поле 'prompt' обязательно (минимум 3 символа) или передайте 'attachments'.",
    });
  if (prompt.length > 4000)
    return jsonError(400, { error: "Поле 'prompt' слишком длинное (максимум 4000 символов)." });

  const resolution = typeof payload["resolution"] === "string" ? payload["resolution"] : "720p";
  if (!(ALLOWED_RES as readonly string[]).includes(resolution))
    return jsonError(400, { error: `Допустимые значения 'resolution': ${ALLOWED_RES.join(", ")}` });

  const rawDuration = typeof payload["duration"] === "number" ? payload["duration"] : 8;
  if (!(rawDuration >= 3 && rawDuration <= 10))
    return jsonError(400, { error: "'duration' должен быть числом от 3 до 10 (секунды)." });

  const aspect = typeof payload["aspect_ratio"] === "string" ? payload["aspect_ratio"] : undefined;
  if (aspect && !(ALLOWED_AR as readonly string[]).includes(aspect))
    return jsonError(400, { error: `Допустимые значения 'aspect_ratio': ${ALLOWED_AR.join(", ")}` });


  const hasVideoInput = attachments.some((a) => a.kind === "video");
  // При редактировании/продолжении клипа aspect_ratio передавать нельзя.
  const useAspect = hasVideoInput ? undefined : aspect;

  const parts: unknown[] = [];
  const extraText: string[] = [];
  for (const a of attachments) {
    if (a.kind === "image") {
      parts.push({ type: "image", data: a.base64, mime_type: a.mime });
    } else if (a.kind === "video") {
      parts.push({ type: "video", data: a.base64, mime_type: a.mime });
    } else if (a.kind === "audio") {
      extraText.push(
        `Аудио-вложение ${a.filename} использовать нельзя; опиши нужный звук словами в промпте.`,
      );
    } else if (/^(text\/|application\/json)/.test(a.mime)) {
      let decoded = "";
      try {
        const bin = atob(a.base64);
        decoded = new TextDecoder().decode(Uint8Array.from(bin, (c) => c.charCodeAt(0)));
      } catch {
        decoded = "";
      }
      if (decoded) extraText.push(`Дополнительный контекст из файла ${a.filename}:\n${decoded}`);
    } else {
      extraText.push(`Файл ${a.filename} (${a.mime}) не поддерживается моделью видео.`);
    }
  }

  const fullPrompt = [prompt, ...extraText].filter(Boolean).join("\n\n");
  if (fullPrompt) parts.unshift({ type: "text", text: fullPrompt });

  const res = await fetch(GATEWAY, {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "google/gemini-omni-1.1-flash",
      input: parts.length > 1 || attachments.length > 0 ? parts : fullPrompt,
      response_format: {
        type: "video",
        resolution,
        duration: `${rawDuration}s`,
        ...(useAspect ? { aspect_ratio: useAspect } : {}),
      },
    }),
  });

  if (!res.ok) {
    const err = (await res.json().catch(() => null)) as { message?: string; type?: string } | null;
    return jsonError(res.status, {
      error: friendly(res.status, err?.message ?? ""),
      code: err?.type,
    });
  }

  return (await res.json()) as { id: string; status: string };
}

async function getJob(id: string, apiKey: string) {
  const res = await fetch(`${GATEWAY}/${id}`, {
    headers: { Authorization: `Bearer ${apiKey}` },
  });
  return { ok: res.ok, status: res.status, body: await res.json().catch(() => null) };
}

async function downloadVideo(id: string, apiKey: string) {
  const res = await fetch(`${GATEWAY}/${id}/content`, {
    headers: { Authorization: `Bearer ${apiKey}` },
  });
  if (!res.ok) return null;
  return await res.arrayBuffer();
}

function videoResponse(bytes: ArrayBuffer, id: string) {
  return new Response(bytes, {
    status: 200,
    headers: {
      "Content-Type": "video/mp4",
      "Content-Disposition": `inline; filename="${id}.mp4"`,
      "X-Video-Id": id,
      ...CORS,
    },
  });
}

/** POST — создать задачу. Синхронно ждёт результат, если не указан async: true. */
export async function postVideoGen(request: Request) {
  const apiKey = process.env["LOVABLE_API_KEY"]!;

  const payload = await readRequestPayload(request);
  if (!payload)
    return jsonError(400, {
      error:
        'Тело запроса должно быть JSON вида { "prompt": "..." } или multipart/form-data с полем file.',
    });

  const created = await createJob(payload);
  if (created instanceof Response) return created;

  const wantAsync = payload["async"] === true || payload["async"] === "true";


  if (wantAsync) {
    return new Response(
      JSON.stringify({ id: created.id, status: created.status }, null, 2),
      { status: 202, headers: { "Content-Type": "application/json", ...CORS } },
    );
  }

  // Синхронный режим: опрашиваем задачу до готовности (обычно 1-3 минуты).
  const deadline = Date.now() + 4 * 60 * 1000;
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, 6000));
    const job = await getJob(created.id, apiKey);
    const j = job.body as
      | { status?: string; error?: { code?: string; message?: string } }
      | null;
    if (!job.ok)
      return jsonError(job.status, {
        error: friendly(job.status, (j as { message?: string } | null)?.message ?? ""),
        details: { id: created.id },
      });
    if (j?.status === "failed")
      return jsonError(502, {
        error: j.error?.message ?? "Генерация не удалась.",
        code: j.error?.code,
        details: { id: created.id },
      });
    if (j?.status === "completed") {
      const bytes = await downloadVideo(created.id, apiKey);
      if (!bytes)
        return jsonError(502, { error: "Не удалось скачать готовое видео.", details: { id: created.id } });
      return videoResponse(bytes, created.id);
    }
  }

  return jsonError(504, {
    error: "Генерация занимает слишком много времени. Запросите статус позже.",
    details: { id: created.id },
  });
}

/** GET ?id=... — статус задачи или готовый MP4. */
export async function getVideoGen(request: Request) {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) return jsonError(500, { error: "LOVABLE_API_KEY не настроен на сервере." });

  const id = new URL(request.url).searchParams.get("id");
  if (!id) return jsonError(400, { error: "Укажите параметр 'id' задачи генерации." });

  const job = await getJob(id, apiKey);
  const j = job.body as
    | { status?: string; progress?: number; message?: string; error?: { code?: string; message?: string } }
    | null;
  if (!job.ok)
    return jsonError(job.status, { error: friendly(job.status, j?.message ?? "") });

  if (j?.status === "failed")
    return jsonError(502, { error: j.error?.message ?? "Генерация не удалась.", code: j.error?.code });

  if (j?.status === "completed") {
    const bytes = await downloadVideo(id, apiKey);
    if (!bytes) return jsonError(502, { error: "Не удалось скачать готовое видео." });
    return videoResponse(bytes, id);
  }

  return new Response(JSON.stringify({ id, status: j?.status, progress: j?.progress }, null, 2), {
    status: 200,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}
