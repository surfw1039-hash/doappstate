/**
 * Единый мультимодальный роутер: /api/text_model и /api/public/text_model.
 *
 * Возможности:
 *   • массив модальностей ответа: output: ["text", "image", "file", "audio", "video"];
 *   • автоопределение задачи — если пользователь просит нарисовать/сгенерировать
 *     картинку, роутер сам включает генерацию графики;
 *   • унифицированный парсер входящих файлов: file {name,type,data},
 *     attachments[], messages[].content[], multipart/form-data;
 *   • серверная распаковка документов (PDF, TXT, DOCX, XLSX, PPTX, ODT) и
 *     передача видео/аудио/картинок бинарным потоком (base64) во Vision-модели;
 *   • строгий SSE: event: status | reasoning | text | image | audio | video |
 *     file | tool | error | done;
 *   • история диалога (messages) и системный промпт (system) на сервере;
 *   • Tool / Function Calling: модель сама вызывает генератор изображений,
 *     озвучку, видео и анализатор файлов.
 */

import {
  AttachmentError,
  collectAttachmentInput,
  dataUrl,
  normalizeAttachments,
  readRequestPayload,
  type NormalizedAttachment,
} from "./attachments.server";
import { extractDocumentText, isDocumentMime, isTextualMime } from "./documents.server";

const BASE = "https://ai.gateway.lovable.dev/v1";

/** Модель по умолчанию для текста/картинок/PDF (Responses API, с рассуждениями). */
const DEFAULT_MODEL = "openai/gpt-6-astra";
/** Модель для аудио/видео вложений (chat/completions, мультимодальная). */
const MEDIA_MODEL = "google/gemini-3.8-flash";

const MAX_TOOL_ROUNDS = 4;

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

const SSE_HEADERS = {
  "Content-Type": "text/event-stream; charset=utf-8",
  "Cache-Control": "no-cache, no-transform",
  Connection: "keep-alive",
  "X-Accel-Buffering": "no",
  ...CORS,
};

export function handleOptions() {
  return new Response(null, { status: 204, headers: CORS });
}

function jsonError(status: number, body: Record<string, unknown>) {
  return new Response(JSON.stringify(body, null, 2), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

function friendly(status: number, message: string) {
  if (status === 402) return `Недостаточно кредитов Lovable AI. ${message}`;
  if (status === 403) return `Запрос заблокирован настройками воркспейса или лимитом. ${message}`;
  if (status === 429) return `Слишком много запросов, попробуйте позже. ${message}`;
  if (status === 401) return "Ключ AI Gateway отсутствует или недействителен.";
  if (status === 400) return `Некорректный запрос: ${message}`;
  return message || "Ошибка текстовой генерации.";
}

/* --------------------------- построение запросов --------------------------- */

export type StreamFormat = "sse" | "ndjson" | "text";

export type OutputKind = "text" | "image" | "audio" | "video" | "file";

type HistoryMessage = { role: "user" | "assistant" | "system"; content: string };

type Parsed = {
  format: StreamFormat;
  prompt: string;
  system?: string;
  model?: string;
  stream: boolean;
  reasoning: "none" | "low" | "medium" | "high";
  attachments: NormalizedAttachment[];
  /** Извлечённый на сервере текст документов, по индексу вложения. */
  docs: Array<{ text: string; truncated: boolean; via: string }>;
  history: HistoryMessage[];
  output: OutputKind[];
  /** Модальности, которые запросил клиент явно (без автоопределения). */
  outputExplicit: boolean;
  toolsEnabled: boolean;
  imagePrompt?: string;
  imageModel?: string;
  voice: string;
  audioModel?: string;
  video: { resolution?: string; duration?: number; aspect_ratio?: string };
  fileName: string;
  fileMime: string;
};

/** Эвристика: пользователь просит именно картинку. */
const IMAGE_INTENT =
  /(нарисуй|нарисовать|дорисуй|перерисуй|сгенерируй\s+(мне\s+)?(картинк|изображени|фото|иллюстрац|логотип|баннер|обложк|аватар|постер|иконк)|сделай\s+(картинк|изображени|иллюстрац|логотип|баннер|постер)|создай\s+(картинк|изображени|иллюстрац|логотип|баннер|постер)|изобрази|отрисуй|draw\s|generate\s+(an?\s+)?(image|picture|illustration|logo|poster|banner)|make\s+(an?\s+)?(image|picture|illustration|logo)|create\s+(an?\s+)?(image|picture|illustration|logo))/i;

const SPEECH_INTENT =
  /(озвучь|озвучить|проговори|скажи\s+голосом|синтез\s+речи|text\s*-?\s*to\s*-?\s*speech|прочитай\s+вслух)/i;

const VIDEO_INTENT =
  /(сними\s+видео|сгенерируй\s+видео|создай\s+видео|сделай\s+видео|анимируй|generate\s+(a\s+)?video|make\s+(a\s+)?video)/i;

async function parseBody(request: Request): Promise<Parsed | Response> {
  const payload = await readRequestPayload(request);
  if (!payload) {
    return jsonError(400, {
      error:
        'Тело запроса должно быть JSON вида { "prompt": "...", "attachments": [...] } или multipart/form-data с полем file.',
    });
  }

  const prompt =
    typeof payload["prompt"] === "string"
      ? payload["prompt"].trim()
      : typeof payload["input"] === "string"
        ? (payload["input"] as string).trim()
        : typeof payload["message"] === "string"
          ? (payload["message"] as string).trim()
          : typeof payload["text"] === "string"
            ? (payload["text"] as string).trim()
            : "";

  let attachments: NormalizedAttachment[];
  try {
    // fetchUrls: ссылки скачиваются и передаются модели инлайн — иначе видео
    // по ссылке может не дойти до модели.
    attachments = await normalizeAttachments(collectAttachmentInput(payload), { fetchUrls: true });
  } catch (e) {
    if (e instanceof AttachmentError) return jsonError(400, { error: e.message });
    throw e;
  }

  if (!prompt && attachments.length === 0)
    return jsonError(400, { error: "Нужно передать 'prompt' и/или 'attachments'." });

  // Серверная распаковка документов: DOCX/XLSX/PPTX/ODT/TXT/CSV/PDF → текст.
  const docs = attachments.map((a) =>
    a.kind === "file" || a.mime === "application/pdf"
      ? extractDocumentText(a)
      : { text: "", truncated: false, via: "none" as const },
  );

  const reasoningRaw = payload["reasoning"];
  const reasoning =
    reasoningRaw === "none" || reasoningRaw === "low" || reasoningRaw === "high"
      ? reasoningRaw
      : "medium";

  const history = normalizeHistory(payload["messages"]);

  const fmtRaw = payload["format"] ?? payload["stream_format"];
  const format: StreamFormat =
    fmtRaw === "ndjson" || fmtRaw === "jsonl"
      ? "ndjson"
      : fmtRaw === "text" || fmtRaw === "plain"
        ? "text"
        : "sse";

  // Что должно быть в ответе: текст и/или медиа-файлы.
  const outRaw = payload["output"] ?? payload["modalities"] ?? payload["return"];
  const outputExplicit = outRaw != null;
  const outList = (Array.isArray(outRaw) ? outRaw : outRaw ? [outRaw] : ["text"])
    .map((v) => String(v).toLowerCase())
    .map((v) =>
      v === "img" || v === "picture" ? "image" : v === "speech" || v === "tts" ? "audio" : v,
    )
    .filter(
      (v): v is OutputKind =>
        v === "text" || v === "image" || v === "audio" || v === "video" || v === "file",
    );
  const output: OutputKind[] = outList.length ? outList : ["text"];

  // Автопереключение на генерацию графики / речи / видео по смыслу запроса.
  if (!outputExplicit) {
    if (IMAGE_INTENT.test(prompt) && !output.includes("image")) output.push("image");
    if (SPEECH_INTENT.test(prompt) && !output.includes("audio")) output.push("audio");
    if (VIDEO_INTENT.test(prompt) && !output.includes("video")) output.push("video");
  }

  const vid = (payload["video"] ?? {}) as Record<string, unknown>;

  return {
    format,
    prompt,
    ...(typeof payload["system"] === "string" ? { system: payload["system"] } : {}),
    ...(typeof payload["model"] === "string" ? { model: payload["model"] } : {}),
    stream: payload["stream"] !== false,
    reasoning,
    attachments,
    docs,
    history,
    output,
    outputExplicit,
    toolsEnabled: payload["tools"] !== false && payload["tool_choice"] !== "none",
    ...(typeof payload["image_prompt"] === "string"
      ? { imagePrompt: payload["image_prompt"] }
      : {}),
    ...(typeof payload["image_model"] === "string" ? { imageModel: payload["image_model"] } : {}),
    voice: typeof payload["voice"] === "string" ? payload["voice"] : "alloy",
    ...(typeof payload["audio_model"] === "string" ? { audioModel: payload["audio_model"] } : {}),
    video: {
      ...(typeof vid["resolution"] === "string" ? { resolution: vid["resolution"] } : {}),
      ...(typeof vid["duration"] === "number" ? { duration: vid["duration"] } : {}),
      ...(typeof vid["aspect_ratio"] === "string" ? { aspect_ratio: vid["aspect_ratio"] } : {}),
    },
    fileName: typeof payload["file_name"] === "string" ? payload["file_name"] : "answer.md",
    fileMime: typeof payload["file_mime"] === "string" ? payload["file_mime"] : "text/markdown",
  };
}

/** История диалога: поддерживает и строковый content, и массив частей. */
function normalizeHistory(raw: unknown): HistoryMessage[] {
  if (!Array.isArray(raw)) return [];
  const out: HistoryMessage[] = [];
  for (const m of raw as Array<Record<string, unknown>>) {
    if (!m || typeof m !== "object") continue;
    const role = String(m["role"] ?? "");
    if (role !== "user" && role !== "assistant" && role !== "system") continue;
    const c = m["content"];
    let content = "";
    if (typeof c === "string") content = c;
    else if (Array.isArray(c)) {
      content = (c as Array<Record<string, unknown>>)
        .map((p) =>
          typeof p === "string"
            ? p
            : typeof p?.["text"] === "string"
              ? (p["text"] as string)
              : "",
        )
        .filter(Boolean)
        .join("\n");
    }
    if (content.trim()) out.push({ role, content });
  }
  return out;
}

function pickModel(p: Parsed) {
  const needsMedia = p.attachments.some((a) => a.kind === "video" || a.kind === "audio");
  // Видео и аудио понимает только мультимодальная модель: даже если клиент
  // указал openai-модель, при таких вложениях переключаемся на неё.
  if (needsMedia && (!p.model || p.model.startsWith("openai/"))) return MEDIA_MODEL;
  if (p.model) return p.model;
  return DEFAULT_MODEL;
}

/** Краткое описание вложения для промпта. */
function describe(p: Parsed, i: number) {
  const a = p.attachments[i] as NormalizedAttachment;
  const doc = p.docs[i];
  const size = a.base64 ? Math.floor((a.base64.length * 3) / 4) : 0;
  return `#${i} ${a.filename} (${a.mime}, ${size} байт${doc?.text ? ", текст извлечён на сервере" : ""})`;
}

/** Блоки контента для /v1/chat/completions (OpenAI-совместимый формат). */
function chatContent(p: Parsed) {
  const parts: unknown[] = [];
  if (p.prompt) parts.push({ type: "text", text: p.prompt });

  p.attachments.forEach((a, i) => {
    const doc = p.docs[i];
    if (a.kind === "image") {
      parts.push({ type: "image_url", image_url: { url: dataUrl(a) } });
    } else if (a.kind === "video") {
      parts.push({ type: "video_url", video_url: { url: dataUrl(a) } });
    } else if (a.kind === "audio") {
      const fmt = (a.mime.split("/")[1] ?? "mp3").replace("mpeg", "mp3").replace("x-wav", "wav");
      parts.push({ type: "input_audio", input_audio: { data: a.base64, format: fmt } });
    } else if (a.mime === "application/pdf") {
      parts.push({
        type: "file",
        file: { filename: a.filename, file_data: `data:${a.mime};base64,${a.base64}` },
      });
      if (doc?.text)
        parts.push({ type: "text", text: `Текст из ${a.filename} (сервер):\n\n${doc.text}` });
    } else if (doc?.text) {
      parts.push({
        type: "text",
        text: `Файл #${i} ${a.filename} (${a.mime}${doc.truncated ? ", обрезан" : ""}):\n\n${doc.text}`,
      });
    } else if (isTextualMime(a.mime)) {
      parts.push({ type: "text", text: `Файл ${a.filename}: (пустой или нечитаемый)` });
    } else {
      parts.push({
        type: "text",
        text: `Прикреплён файл ${describe(p, i)}. Двоичное содержимое напрямую модели не передаётся — используй инструмент analyze_file.`,
      });
    }
  });
  return parts;
}

/** Блоки контента для /v1/responses (OpenAI). */
function responsesContent(p: Parsed) {
  const parts: unknown[] = [];
  if (p.prompt) parts.push({ type: "input_text", text: p.prompt });
  p.attachments.forEach((a, i) => {
    const doc = p.docs[i];
    if (a.kind === "image") {
      parts.push({ type: "input_image", image_url: dataUrl(a) });
    } else if (a.mime === "application/pdf") {
      parts.push({
        type: "input_file",
        filename: a.filename,
        file_data: `data:${a.mime};base64,${a.base64}`,
      });
      if (doc?.text)
        parts.push({ type: "input_text", text: `Текст из ${a.filename} (сервер):\n\n${doc.text}` });
    } else if (doc?.text) {
      parts.push({
        type: "input_text",
        text: `Файл #${i} ${a.filename} (${a.mime}${doc.truncated ? ", обрезан" : ""}):\n\n${doc.text}`,
      });
    } else {
      parts.push({ type: "input_text", text: `Прикреплён файл ${describe(p, i)}.` });
    }
  });
  return parts;
}

/* ------------------------------- SSE-хелперы ------------------------------- */

type Emit = (event: string, data: unknown) => void;

function makeEmitter(
  controller: ReadableStreamDefaultController<Uint8Array>,
  format: StreamFormat,
): Emit {
  const enc = new TextEncoder();
  let firstChunk = true;
  return (event, data) => {
    let chunk: string;
    if (format === "ndjson") {
      chunk = `${JSON.stringify({ event, ...(data as Record<string, unknown>) })}\n`;
    } else if (format === "text") {
      const d = (data ?? {}) as Record<string, unknown>;
      if (event === "text") chunk = String(d["delta"] ?? "");
      else if (event === "delta" || event === "reasoning") chunk = "";
      else if (event === "status") chunk = `[${String(d["stage"])}] ${String(d["message"])}\n`;
      else if (event === "tool") chunk = `[tool] ${String(d["name"])}\n`;
      else if (event === "error") chunk = `\n[error] ${String(d["error"])}\n`;
      else if (event === "file" || event === "image" || event === "audio" || event === "video")
        chunk =
          event === "file"
            ? `\n[file] ${String(d["filename"])} (${String(d["mime"])}, ${String(d["size"])} байт)\n${String(d["data_url"])}\n`
            : "";
      else chunk = "";
    } else {
      chunk = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
      // Некоторые прокси буферизуют маленькие SSE-ответы: первый пакет
      // дополняется безвредным комментарием, чтобы статусы шли сразу.
      if (firstChunk) chunk += `: ${" ".repeat(2048)}\n\n`;
    }
    if (chunk) {
      controller.enqueue(enc.encode(chunk));
      firstChunk = false;
    }
  };
}

/** Текст ответа: строгое событие `text` + легаси-алиас `delta`. */
function emitText(emit: Emit, delta: string) {
  emit("text", { delta });
  emit("delta", { delta });
}

/** Файл: строгое событие по типу (image/audio/video/file) + общее `file`. */
function emitFile(emit: Emit, payload: Record<string, unknown>) {
  const kind = String(payload["kind"] ?? "file");
  if (kind === "image" || kind === "audio" || kind === "video") emit(kind, payload);
  emit("file", payload);
}

async function* sseLines(res: Response) {
  const reader = res.body!.getReader();
  const dec = new TextDecoder();
  let buf = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let idx: number;
    while ((idx = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, idx).trim();
      buf = buf.slice(idx + 1);
      if (line.startsWith("data:")) yield line.slice(5).trim();
    }
  }
}

/* ------------------------------ Function calling --------------------------- */

type ToolSpec = {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
};

function toolSpecs(p: Parsed): ToolSpec[] {
  const tools: ToolSpec[] = [
    {
      name: "generate_image",
      description:
        "Сгенерировать или отредактировать изображение. Использовать всегда, когда пользователь просит картинку, иллюстрацию, логотип, постер или правку присланного изображения. Никогда не рисуй SVG/ASCII вместо этого инструмента.",
      parameters: {
        type: "object",
        additionalProperties: false,
        properties: {
          prompt: { type: "string", description: "Подробное описание изображения на английском или русском." },
          reference_index: {
            type: ["integer", "null"],
            description: "Индекс присланного изображения (#N) для редактирования, иначе null.",
          },
        },
        required: ["prompt", "reference_index"],
      },
    },
    {
      name: "analyze_file",
      description:
        "Получить содержимое присланного файла: извлечённый на сервере текст документа (PDF, DOCX, XLSX, PPTX, TXT, CSV) или метаданные бинарного файла.",
      parameters: {
        type: "object",
        additionalProperties: false,
        properties: {
          index: { type: "integer", description: "Индекс вложения (#N)." },
          max_chars: { type: ["integer", "null"], description: "Ограничение длины ответа." },
        },
        required: ["index", "max_chars"],
      },
    },
    {
      name: "generate_speech",
      description: "Озвучить текст (text-to-speech) и приложить mp3 к ответу.",
      parameters: {
        type: "object",
        additionalProperties: false,
        properties: {
          text: { type: "string" },
          voice: { type: ["string", "null"], description: "Например alloy, nova, verse." },
        },
        required: ["text", "voice"],
      },
    },
    {
      name: "create_file",
      description:
        "Собрать текстовый файл (md, txt, csv, json, код) с результатом и приложить его к ответу.",
      parameters: {
        type: "object",
        additionalProperties: false,
        properties: {
          filename: { type: "string" },
          mime: { type: "string", description: "Например text/markdown, text/csv." },
          content: { type: "string" },
        },
        required: ["filename", "mime", "content"],
      },
    },
  ];

  if (p.output.includes("video")) {
    tools.push({
      name: "generate_video",
      description: "Сгенерировать короткое видео по текстовому описанию (1–3 минуты ожидания).",
      parameters: {
        type: "object",
        additionalProperties: false,
        properties: {
          prompt: { type: "string" },
          duration: { type: ["integer", "null"], description: "Длительность в секундах." },
        },
        required: ["prompt", "duration"],
      },
    });
  }
  return tools;
}

/** Выполняет инструмент и возвращает текстовый результат для модели. */
async function runTool(
  name: string,
  args: Record<string, unknown>,
  ctx: { parsed: Parsed; apiKey: string; emit: Emit; files: Array<Record<string, unknown>> },
): Promise<string> {
  const { parsed, apiKey, emit, files } = ctx;
  const media = await import("./media-out.server");

  const attach = (file: {
    kind: string;
    mime: string;
    filename: string;
    size: number;
    base64: string;
  }) => {
    const payload = {
      kind: file.kind,
      mime: file.mime,
      filename: file.filename,
      size: file.size,
      base64: file.base64,
      data_url: `data:${file.mime};base64,${file.base64}`,
    };
    files.push(payload);
    emitFile(emit, payload);
  };

  try {
    if (name === "generate_image") {
      const prompt = String(args["prompt"] ?? parsed.prompt);
      emit("status", { stage: "image", message: "Генерирую изображение…" });
      const idx = args["reference_index"];
      const refs =
        typeof idx === "number" && parsed.attachments[idx]?.kind === "image"
          ? [
              {
                mime: (parsed.attachments[idx] as NormalizedAttachment).mime,
                base64: (parsed.attachments[idx] as NormalizedAttachment).base64,
              },
            ]
          : parsed.attachments
              .filter((a) => a.kind === "image")
              .map((a) => ({ mime: a.mime, base64: a.base64 }));
      const file = await media.generateImage(apiKey, prompt, refs, parsed.imageModel);
      attach(file);
      return `Изображение сгенерировано и приложено к ответу (${file.filename}, ${file.size} байт).`;
    }

    if (name === "generate_speech") {
      emit("status", { stage: "audio", message: "Озвучиваю текст…" });
      const voice = typeof args["voice"] === "string" ? (args["voice"] as string) : parsed.voice;
      const file = await media.generateSpeech(
        apiKey,
        String(args["text"] ?? parsed.prompt),
        voice,
        parsed.audioModel,
      );
      attach(file);
      return `Аудио готово и приложено (${file.filename}).`;
    }

    if (name === "generate_video") {
      emit("status", { stage: "video", message: "Генерирую видео, это занимает 1–3 минуты…" });
      const file = await media.generateVideo(apiKey, String(args["prompt"] ?? parsed.prompt), {
        ...parsed.video,
        ...(typeof args["duration"] === "number" ? { duration: args["duration"] as number } : {}),
        refs: parsed.attachments
          .filter((a) => a.kind === "image" || a.kind === "video")
          .map((a) => ({ kind: a.kind, mime: a.mime, base64: a.base64 })),
        onProgress: (message) => emit("status", { stage: "video", message }),
      });
      attach(file);
      return `Видео готово и приложено (${file.filename}).`;
    }

    if (name === "create_file") {
      const filename = String(args["filename"] ?? parsed.fileName);
      const mime = String(args["mime"] ?? parsed.fileMime);
      emit("status", { stage: "file", message: `Собираю файл ${filename}…` });
      const file = media.textFile(filename, mime, String(args["content"] ?? ""));
      attach(file);
      return `Файл ${filename} собран и приложен.`;
    }

    if (name === "analyze_file") {
      const i = Number(args["index"] ?? 0);
      const a = parsed.attachments[i];
      if (!a) return `Вложения #${i} нет. Доступно: ${parsed.attachments.length}.`;
      emit("status", { stage: "analyze", message: `Разбираю файл ${a.filename}…` });
      const doc = parsed.docs[i] ?? extractDocumentText(a);
      const limit = typeof args["max_chars"] === "number" ? (args["max_chars"] as number) : 60000;
      if (doc.text)
        return `Файл ${a.filename} (${a.mime}, извлечено: ${doc.via}):\n\n${doc.text.slice(0, limit)}`;
      return `Файл ${a.filename} (${a.mime}) — текст извлечь не удалось; содержимое передано модели напрямую как ${a.kind}.`;
    }

    return `Неизвестный инструмент: ${name}`;
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    emit("error", { error: `Инструмент ${name} завершился ошибкой: ${msg}`, status: 502 });
    return `Ошибка инструмента ${name}: ${msg}`;
  }
}

/* --------------------------------- основное -------------------------------- */

export async function postTextModel(request: Request) {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) return jsonError(500, { error: "LOVABLE_API_KEY не настроен на сервере." });

  const parsed = await parseBody(request);
  if (parsed instanceof Response) return parsed;
  const model = pickModel(parsed);
  const useResponses = model.startsWith("openai/");

  // Не-стриминговый режим: собираем весь текст и файлы на сервере и отдаём JSON.
  if (!parsed.stream) {
    const chunks: string[] = [];
    const reasoning: string[] = [];
    const files: Array<Record<string, unknown>> = [];
    const tools: Array<Record<string, unknown>> = [];
    const err = await runGeneration(parsed, model, useResponses, apiKey, (event, data) => {
      const d = data as { delta?: string };
      if (event === "text" && d.delta) chunks.push(d.delta);
      if (event === "reasoning" && d.delta) reasoning.push(d.delta);
      if (event === "file") files.push(data as Record<string, unknown>);
      if (event === "tool") tools.push(data as Record<string, unknown>);
    });
    if (err) return jsonError(err.status, { error: err.message });
    return new Response(
      JSON.stringify(
        {
          model,
          text: chunks.join(""),
          reasoning: reasoning.join("") || undefined,
          ...(tools.length ? { tool_calls: tools } : {}),
          ...(files.length ? { files } : {}),
        },
        null,
        2,
      ),
      { status: 200, headers: { "Content-Type": "application/json", ...CORS } },
    );
  }

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const emit = makeEmitter(controller, parsed.format);
      emit("status", { stage: "start", message: "Принял запрос, готовлю данные…" });
      if (parsed.attachments.length)
        emit("status", {
          stage: "attachments",
          message: `Разбираю вложения (${parsed.attachments.length}): ${parsed.attachments
            .map((a, i) => `${a.filename} [${a.mime}]${parsed.docs[i]?.text ? " → текст" : ""}`)
            .join(", ")}`,
        });
      emit("status", { stage: "model", message: `Отправляю запрос модели ${model}…` });

      const err = await runGeneration(parsed, model, useResponses, apiKey, emit);
      if (err) emit("error", { error: err.message, status: err.status });
      controller.close();
    },
  });

  const headers =
    parsed.format === "sse"
      ? SSE_HEADERS
      : {
          "Content-Type":
            parsed.format === "ndjson"
              ? "application/x-ndjson; charset=utf-8"
              : "text/plain; charset=utf-8",
          "Cache-Control": "no-cache, no-transform",
          "X-Accel-Buffering": "no",
          ...CORS,
        };

  return new Response(stream, { status: 200, headers });
}

type GenError = { status: number; message: string };

async function runGeneration(
  parsed: Parsed,
  model: string,
  useResponses: boolean,
  apiKey: string,
  emit: Emit,
): Promise<GenError | null> {
  const files: Array<Record<string, unknown>> = [];

  // Только медиа без текста — сразу генерируем файлы.
  if (!parsed.output.includes("text")) {
    const onlyFiles = await runMediaOutputs(parsed, apiKey, parsed.prompt, emit);
    emit("status", { stage: "done", message: "Готово." });
    emit("done", { model, text: "", ...(onlyFiles.length ? { files: onlyFiles } : {}) });
    return null;
  }

  const headers = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${apiKey}`,
    "Lovable-API-Key": apiKey,
  };

  const specs = parsed.toolsEnabled ? toolSpecs(parsed) : [];
  const mediaWanted = parsed.output.filter((o) => o !== "text" && o !== "file");
  const systemText = [
    parsed.system,
    specs.length
      ? "У тебя есть серверные инструменты: generate_image (графика), generate_speech (озвучка), " +
        "create_file (файл с результатом), analyze_file (содержимое вложений)" +
        (parsed.output.includes("video") ? ", generate_video (видео)" : "") +
        ". Вызывай их сам, когда задача этого требует. Никогда не подменяй изображение SVG, HTML, ASCII-артом, base64 или ссылками."
      : "",
    mediaWanted.length
      ? `Клиент запросил модальности: ${mediaWanted.join(", ")}. Соответствующие файлы будут приложены автоматически; в тексте дай короткий комментарий (1–2 предложения).`
      : "",
  ]
    .filter(Boolean)
    .join("\n\n");

  const state = {
    text: "",
    answerStarted: false,
    reasoningSeen: false,
  };

  const err = useResponses
    ? await runResponsesLoop(parsed, model, apiKey, headers, systemText, specs, emit, state, files)
    : await runChatLoop(parsed, model, headers, systemText, specs, emit, state, files);
  if (err) return err;

  const extra = await runMediaOutputs(parsed, apiKey, state.text, emit, files);
  files.push(...extra);
  emit("status", { stage: "done", message: "Готово." });
  emit("done", { model, text: state.text, ...(files.length ? { files } : {}) });
  return null;
}

type LoopState = { text: string; answerStarted: boolean; reasoningSeen: boolean };

function makeFlusher(emit: Emit, state: LoopState) {
  let pendingText = "";
  let pendingReasoning = "";
  const shouldFlush = (v: string) => v.length >= 80 || /[.!?;:]\s$|\n$/.test(v);
  return {
    text(d: string) {
      if (!state.answerStarted) {
        state.answerStarted = true;
        this.flushReasoning();
        emit("status", { stage: "answering", message: "Пишу ответ…" });
      }
      state.text += d;
      pendingText += d;
      if (shouldFlush(pendingText)) this.flushText();
    },
    reasoning(d: string) {
      if (state.answerStarted) return;
      if (!state.reasoningSeen) {
        state.reasoningSeen = true;
        emit("status", { stage: "reasoning", message: "Рассуждаю над задачей…" });
      }
      pendingReasoning += d;
      if (shouldFlush(pendingReasoning)) this.flushReasoning();
    },
    flushText() {
      if (!pendingText) return;
      emitText(emit, pendingText);
      pendingText = "";
    },
    flushReasoning() {
      if (!pendingReasoning) return;
      emit("reasoning", { delta: pendingReasoning });
      pendingReasoning = "";
    },
    flushAll() {
      this.flushReasoning();
      this.flushText();
    },
  };
}

async function gatewayError(res: Response): Promise<GenError> {
  const raw = await res.text().catch(() => "");
  let msg = raw;
  try {
    const j = JSON.parse(raw) as { message?: string; error?: { message?: string } };
    msg = j.error?.message ?? j.message ?? raw;
  } catch {
    /* not json */
  }
  return { status: res.status, message: friendly(res.status, msg) };
}

/* ------------------------ ветка /v1/chat/completions ----------------------- */

async function runChatLoop(
  parsed: Parsed,
  model: string,
  headers: Record<string, string>,
  systemText: string,
  specs: ToolSpec[],
  emit: Emit,
  state: LoopState,
  files: Array<Record<string, unknown>>,
): Promise<GenError | null> {
  const messages: Array<Record<string, unknown>> = [
    ...(systemText ? [{ role: "system", content: systemText }] : []),
    ...parsed.history,
    { role: "user", content: chatContent(parsed) },
  ];
  const flush = makeFlusher(emit, state);

  for (let round = 0; round <= MAX_TOOL_ROUNDS; round++) {
    const body = {
      model,
      stream: true,
      messages,
      ...(specs.length
        ? {
            tools: specs.map((t) => ({
              type: "function",
              function: { name: t.name, description: t.description, parameters: t.parameters },
            })),
            tool_choice: "auto",
          }
        : {}),
    };

    let res: Response;
    try {
      res = await fetch(`${BASE}/chat/completions`, {
        method: "POST",
        headers,
        body: JSON.stringify(body),
      });
    } catch (e) {
      return { status: 502, message: `Не удалось связаться с AI Gateway: ${String(e)}` };
    }
    if (!res.ok || !res.body) return gatewayError(res);

    if (round === 0) emit("status", { stage: "thinking", message: "Модель начала работу…" });

    const calls = new Map<number, { id: string; name: string; args: string }>();
    let assistantText = "";

    for await (const data of sseLines(res)) {
      if (!data || data === "[DONE]") continue;
      let evt: Record<string, unknown>;
      try {
        evt = JSON.parse(data) as Record<string, unknown>;
      } catch {
        continue;
      }
      const choice = (
        evt["choices"] as Array<{ delta?: Record<string, unknown> }> | undefined
      )?.[0];
      const delta = choice?.delta;
      if (!delta) continue;

      const r = (delta["reasoning"] ?? delta["reasoning_content"]) as string | undefined;
      if (r) flush.reasoning(r);

      const c = delta["content"] as string | undefined;
      if (c) {
        assistantText += c;
        flush.text(c);
      }

      const tc = delta["tool_calls"] as
        | Array<{ index?: number; id?: string; function?: { name?: string; arguments?: string } }>
        | undefined;
      if (tc) {
        for (const call of tc) {
          const i = call.index ?? 0;
          const cur = calls.get(i) ?? { id: "", name: "", args: "" };
          if (call.id) cur.id = call.id;
          if (call.function?.name) cur.name = call.function.name;
          if (call.function?.arguments) cur.args += call.function.arguments;
          calls.set(i, cur);
        }
      }
    }
    flush.flushAll();

    if (!calls.size) return null;

    messages.push({
      role: "assistant",
      content: assistantText || null,
      tool_calls: [...calls.entries()].map(([i, c]) => ({
        id: c.id || `call_${i}`,
        type: "function",
        function: { name: c.name, arguments: c.args || "{}" },
      })),
    });

    for (const [i, c] of calls) {
      let args: Record<string, unknown> = {};
      try {
        args = JSON.parse(c.args || "{}") as Record<string, unknown>;
      } catch {
        /* пустые аргументы */
      }
      emit("tool", { name: c.name, arguments: args });
      const result = await runTool(c.name, args, { parsed, apiKey: headers["Lovable-API-Key"] as string, emit, files });
      messages.push({ role: "tool", tool_call_id: c.id || `call_${i}`, content: result });
    }
    state.answerStarted = false;
  }
  return null;
}

/* ---------------------------- ветка /v1/responses -------------------------- */

async function runResponsesLoop(
  parsed: Parsed,
  model: string,
  apiKey: string,
  headers: Record<string, string>,
  systemText: string,
  specs: ToolSpec[],
  emit: Emit,
  state: LoopState,
  files: Array<Record<string, unknown>>,
): Promise<GenError | null> {
  const input: unknown[] = [
    ...(systemText ? [{ role: "system", content: [{ type: "input_text", text: systemText }] }] : []),
    ...parsed.history.map((m) => ({
      role: m.role,
      content: [{ type: m.role === "assistant" ? "output_text" : "input_text", text: m.content }],
    })),
    { role: "user", content: responsesContent(parsed) },
  ];
  const flush = makeFlusher(emit, state);

  for (let round = 0; round <= MAX_TOOL_ROUNDS; round++) {
    const body = {
      model,
      stream: true,
      store: false,
      input,
      reasoning: { effort: parsed.reasoning === "none" ? "low" : parsed.reasoning, summary: "auto" },
      ...(specs.length
        ? {
            tools: specs.map((t) => ({
              type: "function",
              name: t.name,
              description: t.description,
              parameters: t.parameters,
              strict: false,
            })),
            tool_choice: "auto",
          }
        : {}),
    };

    let res: Response;
    try {
      res = await fetch(`${BASE}/responses`, {
        method: "POST",
        headers,
        body: JSON.stringify(body),
      });
    } catch (e) {
      return { status: 502, message: `Не удалось связаться с AI Gateway: ${String(e)}` };
    }
    if (!res.ok || !res.body) return gatewayError(res);

    if (round === 0) emit("status", { stage: "thinking", message: "Модель начала работу…" });

    let output: Array<Record<string, unknown>> = [];

    for await (const data of sseLines(res)) {
      if (!data || data === "[DONE]") continue;
      let evt: Record<string, unknown>;
      try {
        evt = JSON.parse(data) as Record<string, unknown>;
      } catch {
        continue;
      }
      const type = evt["type"] as string | undefined;
      if (type === "response.reasoning_summary_text.delta") {
        flush.reasoning(String(evt["delta"] ?? ""));
      } else if (type === "response.output_text.delta") {
        flush.text(String(evt["delta"] ?? ""));
      } else if (type === "response.completed") {
        output =
          ((evt["response"] as { output?: Array<Record<string, unknown>> } | undefined)?.output ??
            []) as Array<Record<string, unknown>>;
      } else if (type === "response.failed" || type === "error") {
        const message =
          ((evt["response"] as { error?: { message?: string } } | undefined)?.error?.message ??
            (evt["message"] as string)) ||
          "Модель вернула ошибку.";
        return { status: 502, message };
      }
    }
    flush.flushAll();

    const calls = output.filter((o) => o["type"] === "function_call");
    if (!calls.length) return null;

    // Возвращаем модели её же элементы (включая рассуждения) и результаты инструментов.
    input.push(...output);
    for (const call of calls) {
      let args: Record<string, unknown> = {};
      try {
        args = JSON.parse(String(call["arguments"] ?? "{}")) as Record<string, unknown>;
      } catch {
        /* пустые аргументы */
      }
      const name = String(call["name"] ?? "");
      emit("tool", { name, arguments: args });
      const result = await runTool(name, args, { parsed, apiKey, emit, files });
      input.push({
        type: "function_call_output",
        call_id: String(call["call_id"] ?? call["id"] ?? ""),
        output: result,
      });
    }
    state.answerStarted = false;
  }
  return null;
}

/* ------------------------- медиа и файлы в ответе -------------------------- */

/**
 * Догенерирует файлы, которые клиент запросил явно в `output`, но модель не
 * создала сама через инструменты.
 */
async function runMediaOutputs(
  parsed: Parsed,
  apiKey: string,
  text: string,
  emit: Emit,
  already: Array<Record<string, unknown>> = [],
): Promise<Array<Record<string, unknown>>> {
  const done = new Set(already.map((f) => String(f["kind"])));
  const wanted = parsed.output.filter((o) => o !== "text" && !done.has(o));
  if (!wanted.length) return [];

  const { generateImage, generateSpeech, generateVideo, textFile, MediaError } = await import(
    "./media-out.server"
  );

  const refs = parsed.attachments
    .filter((a) => a.kind === "image" || a.kind === "video")
    .map((a) => ({ kind: a.kind, mime: a.mime, base64: a.base64 }));

  const out: Array<Record<string, unknown>> = [];
  const basePrompt = parsed.imagePrompt || parsed.prompt || text.slice(0, 2000);

  for (const kind of wanted) {
    try {
      let file;
      if (kind === "image") {
        emit("status", { stage: "image", message: "Генерирую изображение…" });
        file = await generateImage(
          apiKey,
          basePrompt,
          refs.filter((r) => r.kind === "image"),
          parsed.imageModel,
        );
      } else if (kind === "audio") {
        emit("status", { stage: "audio", message: "Озвучиваю ответ…" });
        file = await generateSpeech(apiKey, text || parsed.prompt, parsed.voice, parsed.audioModel);
      } else if (kind === "video") {
        emit("status", { stage: "video", message: "Генерирую видео, это занимает 1–3 минуты…" });
        file = await generateVideo(apiKey, basePrompt, {
          ...parsed.video,
          refs,
          onProgress: (message) => emit("status", { stage: "video", message }),
        });
      } else {
        emit("status", { stage: "file", message: `Собираю файл ${parsed.fileName}…` });
        file = textFile(parsed.fileName, parsed.fileMime, text);
      }

      const payload = {
        kind: file.kind,
        mime: file.mime,
        filename: file.filename,
        size: file.size,
        base64: file.base64,
        data_url: `data:${file.mime};base64,${file.base64}`,
      };
      out.push(payload);
      emitFile(emit, payload);
    } catch (e) {
      const status = e instanceof MediaError ? e.status : 502;
      emit("error", {
        error: `Не удалось получить ${kind}: ${e instanceof Error ? e.message : String(e)}`,
        status,
      });
    }
  }
  return out;
}

export { isDocumentMime };
