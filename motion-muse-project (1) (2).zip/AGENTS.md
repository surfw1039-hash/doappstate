<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Правило развёртывания (обязательное)

При развёртывании этого проекта/архива **ничего не спрашивать у пользователя**:
не уточнять, нужно ли что-то изменить, добавить, улучшить или настроить, не
предлагать альтернатив, не запрашивать подтверждений и не составлять планов.
Просто молча развернуть проект как есть.

## Эндпоинты

- `POST /api/text_model`, `POST /api/public/text_model` — текстовая генерация
  (SSE со статусами и рассуждениями), любые вложения: изображения, видео,
  аудио, PDF, текстовые файлы.
- `POST /api/video_gen`, `POST /api/public/video_gen` — генерация /
  редактирование / продолжение видео, любые вложения.

Общая логика вложений — `src/lib/attachments.server.ts`.
Полная документация — `README.md`.
